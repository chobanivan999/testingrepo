import os
import json
from flask_cors import CORS
from flask import Flask, render_template, request

app = Flask(__name__)
CORS(app)


filename = 'courses.json'
SITE_ROOT = os.path.realpath(os.path.dirname(__file__))

def writeJSON(data = []):
    if (len(data)) or (len(data) == 0 and not os.path.exists(filename)):
        with open(filename, 'w+') as f:
            f.write(json.dumps(data, indent=4))            
            f.close

# Get course
def readJSON():
    f = open(filename)
    data = json.load(f)

    return data

# api document
@app.route("/")
def index():
    return render_template('index.html')

# create or get
@app.route('/course', methods=['GET', 'POST'])
def addOrGetcourse():
    if request.method == 'POST':
        try:
            data = request.values.get('data', '')
            if data:
                row = json.loads(data)
                courses = readJSON()
                courses.append(row)
                writeJSON(courses)

                return { "code" : 201, "msg" : "success" }
            return { "code" : 400, "msg" : "Bad Request"}
        except Exception as e:
            return {"code": 500, "msg": str(e)}
    elif request.method == 'GET':
        return readJSON()
    else:
        return {"code": 404, "msg": "Not Found"}

# Update or delete the course
@app.route('/course/<string:id>', methods=['PUT', 'DELETE'])
def updateCourse(id):
    if request.method == 'PUT':
        try:
            data = request.values.get('data', '')
            if data:
                row = json.loads(data)
                courses = readJSON()
                courses = list(filter(lambda x: x['id']!=id, courses))
                courses.append(row)
                writeJSON(courses)

                return { "code" : 200, "msg" : "success" }
            return { "code" : 400, "msg" : "Bad Request"}
        except Exception as e:
            return {"code": 500, "msg": str(e)}
    elif request.method == 'DELETE':
        courses = readJSON()
        courses = list(filter(lambda x: x['id']!=id, courses))
        writeJSON(courses)
        return { "code" : 200, "msg" : "success" }
    else:
        return {"code": 404, "msg": "Not Found"}
    
if __name__ == '__main__':
    writeJSON()
    app.run()