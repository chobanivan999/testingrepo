import sys
import json
import re

filename = sys.argv[1]
bot_pattern = sys.argv[2]
usr_pattern = sys.argv[3]
delItems = ["image omitted", "WhatsApp detected too much traffic"]
if filename:
    file1 = open(filename, 'r', encoding="utf8")
    lines = file1.readlines()
    idx = 0
    idx1 = 0
    jsonlstr = ""
    asked = False
    answered = False
    usr_lines = []

    idx = 0
    for line in lines:
        if line.count(usr_pattern) :
            usr_lines.append(idx)
        idx += 1

    jsondata = []
    question = ""
    for i in range(len(usr_lines)-1):
        question = lines[usr_lines[i]].split(usr_pattern)[1].replace("\n", "")
        json1 = {"user": question, "assist": []}

        for j in range(usr_lines[i]+1, usr_lines[i+1]):
            answer = lines[j].replace("\n", "")
            if answer.count(bot_pattern):
                answer = answer.split(bot_pattern)[1]
            if answer:
                for di in delItems:
                    if answer.count(di):
                        json1 = None
                        break
                if json1:
                    json1['assist'].append(answer)
        if json1:
            jsondata.append(json1)
            print(json1)
    print(len(jsondata))

    with open(filename.split(".")[0] + '.jsonl', 'w') as outfile:
        for entry in jsondata:
            json1 = {"messages": [
                {"role": "system", "content": "Do assistance for customer"}, 
                {"role": "user", "content": entry['user']}, 
                {"role": "assistant", "content": "\n".join(entry['assist'])}]} 
            json.dump(json1, outfile)
            outfile.write('\n')