<?php $__env->startSection('content'); ?>
<div id="wrapper">
    <nav class="navbar-default navbar-static-side chatbodybg" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <div class="dropdown-toggle">
                            <h3 class="block m-t-xs font-bold text-white">
                                <a href="#">
                                    Aperion AI
                                </a>
                            </h3>
                        </div>
                    </div>
                </li>
                <li section="#category">
                    <a href="#" class="nav-link nav-label myitem">
                        <i class="fa fa-tasks"></i>
                        Category
                    </a>
                </li>
                <li section="#conversation">
                    <a href="#" class="nav-link nav-label myitem">
                        <i class="fa fa-wechat (alias)"></i>
                        Conversasion
                    </a>  
                </li>
            </ul>
        </div>
    </nav>

    <div id="page-wrapper" class="gray-bg">    
        <div id="category" class="sb-hide wrapper wrapper-content animated fadeInRight">
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h4 style="padding-top: 15px;"><i class="fa fa-tasks"></i> <b>Category Management</b></h4>
                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
            <div class="col-lg-12">
                <div class="ibox ">
                    <div class="ibox-content category_div">
                        <div class="sk-spinner sk-spinner-wave">
                            <div class="sk-rect1"></div>
                            <div class="sk-rect2"></div>
                            <div class="sk-rect3"></div>
                            <div class="sk-rect4"></div>
                            <div class="sk-rect5"></div>
                        </div>
                        <div class="row">
                            <div class="col-lg-11">
                                <input type="text" class="form-control form-control-sm m-b-sm" id="category_input" placeholder="Input the category" rows=3 data="-1">
                            </div>
                            <div class="col-lg-1">
                                <button class="btn btn-success" id="save_categry_btn">Save</button>
                            </div>
                        </div>

                        <table class="footable table table-stripped" data-page-size=10 id="category_tbl">
                            <thead>
                                <tr>
                                    <th width="8%">No</th>
                                    <th width="84%">Name</th>
                                    <th width="8%">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr qa-id="<?php echo e($cate->id); ?>">
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($cate->name); ?></td>
                                
                                    <td><a data-toggle="modal" href="#" class="remove_category_btn">
                                        <i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="6">
                                        <ul class="pagination float-right"></ul>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div id="conversation" class="sb-hide wrapper wrapper-content animated fadeInRight">
            <div class="col-lg-12">
                <h2>Conversasion</h2>
            </div>
        </div>

        <div class="footer myfooter">
            <div class="pull-right">
                ...
            </div>
            <div>
                <strong>Copyright</strong> Aperion AI &copy; <?=date('Y')+1;?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work\2023\AperionAI\work\aperion-chat-app\resources\views/home.blade.php ENDPATH**/ ?>