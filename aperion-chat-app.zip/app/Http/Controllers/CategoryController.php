<?php

namespace App\Http\Controllers;
use App\Models\ChatCategory;

use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $categories = ChatCategory::all();
        return view('home',  ['categories' => $categories]);
    }

    /**
     * Get the categories
     *
     * @return Array
     */
    public function getAll()
    {
        try {
            $categories = ChatCategory::all();
            return $categories;
        }
        catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Store a new category
     *
     * @return bool|String
     */
    public function store(Request $request)
    {
        try {
            $name       = $request->name;
            
            $chatCategory = new ChatCategory;
            $chatCategory->name = $name;
            $result = $chatCategory->save();
    
            return $result;
        }
        catch (\Exception $e) {
            return $e->getMessage();
        }
    }
}
