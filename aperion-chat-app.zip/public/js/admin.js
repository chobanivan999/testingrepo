$(function () {
  $.ajaxSetup({
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
  });
  // set the page state
  var pagemenu = localStorage.getItem("menu");
  var sidemenu_li = $("ul#side-menu").children();
  if (pagemenu) {
    for (let i = 0; i < sidemenu_li.length; i++) {        
      $(sidemenu_li[i]).removeClass("active");
    }
    
    var sections = ["#category", "#conversation"];
    sections.forEach(sec => {
      $(sec).addClass("sb-hide");
    });

    $("li[section='"+pagemenu+"']").addClass("active");
    $(pagemenu).removeClass("sb-hide");
  } else {
    $("#category").removeClass("sb-hide");
    $("li[section='#category']").addClass("active");
  }

  $("a.myitem").on('click', function(e) {
      var sections = ["#category", "#conversation"];
      var li = $(e.target).parent();
      var section = li.attr('section');
      $(section).removeClass("sb-hide");
      sections.forEach(item => {
        if (item != section) {
          $(item).addClass("sb-hide");
        }
      });
      var myitems = $("a.myitem");
      for (var i = 0; i < myitems.length; i++) {
        if (myitems[i] == e.target) {
          localStorage.setItem('menu', sections[i]);
          if ($($(e.target).parent()).hasClass("nav-second-level")) {
            $($(e.target).parent()).addClass("active");
          } else {
            $(li).addClass("active");
          }
        } else {
          if ($($(myitems[i]).parent()).hasClass("nav-second-level")) {
            $($(myitems[i]).parent()).removeClass("active");
          } else {
            $(myitems[i]).parent().removeClass("active");
          }
        }
      }
  })

  $("#category_tbl").footable();
});

// Save category
$("#save_categry_btn").on("click", function(e) {
  let category = $("#category_input").val().trim();
  if (category) {
    $.ajax({
      type: 'post',
      url: 'category',
      data: {
        name: category
      },
      success: function(e)
      {
        $.ajax({
          type: 'get',
          url: 'category',
          success: function(e1)
          {
            console.log(e1);
          }
        });
      }
    });
  }
});